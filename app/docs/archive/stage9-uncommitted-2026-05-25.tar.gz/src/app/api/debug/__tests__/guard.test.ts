import { describe, it, expect, afterEach, vi } from "vitest";
import { blockInProduction } from "../_guard";

describe("blockInProduction", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("returns 401 when NODE_ENV=production", () => {
    vi.stubEnv("NODE_ENV", "production");
    const r = blockInProduction();
    expect(r).not.toBeNull();
    expect(r?.status).toBe(401);
  });

  it("returns null in development", () => {
    vi.stubEnv("NODE_ENV", "development");
    expect(blockInProduction()).toBeNull();
  });
});
