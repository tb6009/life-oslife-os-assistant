import { NextResponse } from "next/server";

export function blockInProduction(): NextResponse | null {
  if (process.env.NODE_ENV === "production") {
    return new NextResponse(null, { status: 401 });
  }
  return null;
}
