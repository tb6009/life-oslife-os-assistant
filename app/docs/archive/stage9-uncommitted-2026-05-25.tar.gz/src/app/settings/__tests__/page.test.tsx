import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import SettingsPage from "../page";

vi.mock("next-auth/react", () => ({
  useSession: () => ({ data: null }),
  signIn: vi.fn(),
  signOut: vi.fn(),
}));

describe("SettingsPage copy", () => {
  it("uses 하루 wording for API key purpose", () => {
    render(<SettingsPage />);
    expect(
      screen.getByText(/하루\(어시스턴트\) 대화에 사용/)
    ).toBeInTheDocument();
  });

  it("does NOT mention friends/모미/마음 in API key purpose", () => {
    render(<SettingsPage />);
    expect(screen.queryByText(/친구들\(모미\/마음\)/)).not.toBeInTheDocument();
  });
});
