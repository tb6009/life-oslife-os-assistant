import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import BottomNav from "../BottomNav";

vi.mock("next/navigation", () => ({
  usePathname: () => "/",
  useRouter: () => ({ push: vi.fn() }),
}));

describe("BottomNav", () => {
  it("renders tabs in order: 홈 → 기록 → 하루 → 설정", () => {
    render(<BottomNav />);
    const labels = screen.getAllByRole("button").map((b) => b.textContent);
    // textContent contains both 라벨 + role caption — match using order
    expect(labels[0]).toMatch(/홈/);
    expect(labels[1]).toMatch(/기록/);
    expect(labels[2]).toMatch(/하루/);
    expect(labels[3]).toMatch(/설정/);
  });
});
