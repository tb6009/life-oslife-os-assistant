"use client";

import { useState, type KeyboardEvent } from "react";

interface Props {
  onSubmit: (text: string) => void;
  loading?: boolean;
}

export function ChatInput({ onSubmit, loading }: Props) {
  const [value, setValue] = useState("");

  function submit() {
    const trimmed = value.trim();
    if (!trimmed) return;
    onSubmit(trimmed);
    setValue("");
  }

  function onKey(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  }

  return (
    <div className="flex gap-2 px-4 py-3 border-t border-gray-100 bg-white">
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={onKey}
        disabled={loading}
        placeholder="메시지를 입력하세요"
        className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-full text-sm"
      />
      <button
        onClick={submit}
        disabled={loading}
        className="px-4 py-2 bg-black text-white rounded-full text-sm disabled:opacity-50"
      >
        보내기
      </button>
    </div>
  );
}
