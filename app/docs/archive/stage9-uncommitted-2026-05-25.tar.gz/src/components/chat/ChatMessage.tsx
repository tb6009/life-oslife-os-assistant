"use client";

import { renderMarkdown } from "@/lib/markdown";

interface Props {
  role: "user" | "assistant";
  text: string;
}

export function ChatMessage({ role, text }: Props) {
  const isUser = role === "user";
  return (
    <div
      className={`flex ${isUser ? "justify-end" : "justify-start"} my-1`}
    >
      <div
        className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm leading-snug ${
          isUser ? "bg-black text-white" : "bg-gray-100 text-gray-900"
        }`}
        dangerouslySetInnerHTML={{ __html: renderMarkdown(text) }}
      />
    </div>
  );
}
