import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import { ChatInput } from "../ChatInput";

describe("ChatInput", () => {
  it("fires onSubmit with trimmed text on Enter", async () => {
    const onSubmit = vi.fn();
    render(<ChatInput onSubmit={onSubmit} />);
    const input = screen.getByPlaceholderText(/메시지/);

    await userEvent.type(input, "  안녕  {Enter}");
    expect(onSubmit).toHaveBeenCalledWith("안녕");
  });

  it("does not fire on empty input", async () => {
    const onSubmit = vi.fn();
    render(<ChatInput onSubmit={onSubmit} />);
    const input = screen.getByPlaceholderText(/메시지/);

    await userEvent.type(input, "{Enter}");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("disables when loading prop is true", () => {
    render(<ChatInput onSubmit={vi.fn()} loading />);
    expect(screen.getByPlaceholderText(/메시지/)).toBeDisabled();
  });
});
