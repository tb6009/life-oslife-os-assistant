import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { ChatMessage } from "../ChatMessage";

describe("ChatMessage", () => {
  it("renders user message right-aligned", () => {
    const { container } = render(
      <ChatMessage role="user" text="안녕" />
    );
    expect(screen.getByText("안녕")).toBeInTheDocument();
    expect(container.firstChild).toHaveClass(/justify-end/);
  });

  it("renders assistant message with markdown bold", () => {
    render(<ChatMessage role="assistant" text="**굵게** 말함" />);
    expect(document.querySelector("strong")?.textContent).toBe("굵게");
  });
});
