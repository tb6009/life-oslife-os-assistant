"use client";

import {
  useJournalEntries,
  useMonthlyReview,
  useWeeklyReviewsByMonth,
} from "@/lib/supabase/queries";
import { getMonthRange, getYearWeek } from "@/lib/time/range";
import { buildDayStatus } from "@/hooks/useReviewStatus";

interface Props {
  year: number;
  month: number; // 1-12
  onDayClick?: (date: string) => void;
}

const REVIEW_PENDING = "#DC2626";
const REVIEW_WEEK_DONE = "#2563eb";
const REVIEW_DAY_DONE = "#16a34a";
const REVIEW_MONTH_DONE = "#16a34a";

export function CalendarGrid({ year, month, onDayClick }: Props) {
  const range = getMonthRange(year, month);
  const yearMonth = `${year}-${String(month).padStart(2, "0")}`;

  const { data: journals = [] } = useJournalEntries(range.start, range.end);
  const { data: monthlyReview } = useMonthlyReview(yearMonth);
  const { data: weeklyReviews = [] } = useWeeklyReviewsByMonth(yearMonth);
  const monthlyDone = !!(monthlyReview?.memorable || monthlyReview?.next_goal);

  const weeklyMap = new Map(
    weeklyReviews.map((r: any) => [r.year_week, r])
  );

  const cells: { date: Date; status: ReturnType<typeof buildDayStatus> }[] = [];
  for (let i = 0; i < range.days; i++) {
    const d = new Date(year, month - 1, i + 1);
    cells.push({
      date: d,
      status: buildDayStatus(d, journals as any, weeklyMap, getYearWeek),
    });
  }

  return (
    <div className="px-7 py-3">
      <div className="grid grid-cols-7 gap-1 text-[0.7rem]">
        {["일", "월", "화", "수", "목", "금", "토"].map((label, i) => (
          <div
            key={label}
            className="text-center py-1"
            style={{ color: i === 0 ? REVIEW_PENDING : "#9ca3af" }}
          >
            {label}
          </div>
        ))}
        {/* leading blanks */}
        {Array.from({ length: range.firstDayOfWeek }).map((_, i) => (
          <div key={`b${i}`} />
        ))}
        {cells.map(({ date, status }) => {
          const isLastDay = date.getDate() === range.days;
          const cellBg =
            isLastDay && monthlyDone ? REVIEW_MONTH_DONE : "transparent";
          const cellColor = isLastDay && monthlyDone ? "#fff" : "#000";
          const dotColor = status.isSunday
            ? status.weeklyDone
              ? REVIEW_WEEK_DONE
              : REVIEW_PENDING
            : status.dailyDone
              ? REVIEW_DAY_DONE
              : null;
          return (
            <button
              key={status.date}
              onClick={() => onDayClick?.(status.date)}
              className="relative border border-gray-100 p-1 text-left"
              style={{
                aspectRatio: "1.5",
                background: cellBg,
                color: cellColor,
              }}
              aria-label={status.date}
            >
              <div className="text-xs">{date.getDate()}</div>
              {dotColor && (
                <div
                  className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full"
                  style={{ background: dotColor }}
                />
              )}
              {isLastDay && !monthlyDone && (
                <div
                  className="absolute bottom-0.5 right-1 text-[0.5rem] font-bold"
                  style={{ color: REVIEW_PENDING }}
                >
                  月
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
