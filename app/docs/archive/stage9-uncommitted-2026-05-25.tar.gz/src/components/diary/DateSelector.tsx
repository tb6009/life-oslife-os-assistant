"use client";

import { useEffect, useRef } from "react";
import { toDateStr } from "@/lib/time/range";

const ITEM_WIDTH = 52;
const TOTAL_DAYS = 61;
const CENTER_INDEX = 30;

const dayLabels = ["일", "월", "화", "수", "목", "금", "토"];

interface Props {
  value: Date;
  onChange: (date: Date) => void;
}

export function DateSelector({ value, onChange }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Anchor day: today. The strip shows ±30 days around it.
  const anchor = new Date();
  const dates: Date[] = [];
  for (let i = 0; i < TOTAL_DAYS; i++) {
    const d = new Date(anchor);
    d.setDate(anchor.getDate() + (i - CENTER_INDEX));
    dates.push(d);
  }

  // Center selected on mount + on value change
  useEffect(() => {
    if (!scrollRef.current) return;
    const selectedIndex = dates.findIndex(
      (d) => toDateStr(d) === toDateStr(value)
    );
    if (selectedIndex < 0) return;
    const container = scrollRef.current;
    const target =
      selectedIndex * ITEM_WIDTH -
      container.clientWidth / 2 +
      ITEM_WIDTH / 2;
    container.scrollLeft = target;
  }, [value, dates]);

  return (
    <div
      ref={scrollRef}
      className="overflow-x-auto no-scrollbar"
      style={{ scrollSnapType: "x mandatory" }}
    >
      <div
        className="flex items-center"
        style={{ width: `${TOTAL_DAYS * ITEM_WIDTH}px` }}
      >
        {dates.map((d, idx) => {
          const isSelected = toDateStr(d) === toDateStr(value);
          const isSunday = d.getDay() === 0;
          const distance = Math.abs(idx - dates.findIndex(x => toDateStr(x) === toDateStr(value)));
          const opacity = isSelected ? 1 : Math.max(0.4, 1 - distance * 0.15);
          return (
            <button
              key={idx}
              data-selected={isSelected}
              aria-label={toDateStr(d)}
              onClick={() => onChange(d)}
              style={{
                width: ITEM_WIDTH,
                opacity,
                background: isSelected
                  ? isSunday
                    ? "#DC2626"
                    : "#000"
                  : "transparent",
                color: isSelected ? "#fff" : "#333",
                borderRadius: 8,
                padding: "8px 0",
                textAlign: "center",
                border: "none",
                cursor: "pointer",
              }}
            >
              <div style={{ fontSize: "0.6rem", opacity: 0.7 }}>
                {dayLabels[d.getDay()]}
              </div>
              <div style={{ fontWeight: 700 }}>{d.getDate()}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
