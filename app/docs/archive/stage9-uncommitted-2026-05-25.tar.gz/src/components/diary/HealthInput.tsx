"use client";

import { useState, useEffect } from "react";
import { useHealthLog, useUpsertHealthLog } from "@/lib/supabase/queries";
import { useUpsertJournalEntry } from "@/lib/supabase/queries";
import { useToast } from "@/hooks/useToast";
import { emotionList, getEmotionColor } from "@/lib/theme/emotions";

interface Props {
  date: string; // YYYY-MM-DD
}

export function HealthInput({ date }: Props) {
  const { data: health } = useHealthLog(date);
  const upsertHealth = useUpsertHealthLog();
  const upsertJournal = useUpsertJournalEntry();
  const { toast } = useToast();

  const [sleepH, setSleepH] = useState("");
  const [sleepM, setSleepM] = useState("");
  const [condition, setCondition] = useState<number | null>(null);
  const [coffee, setCoffee] = useState(0);
  const [exercise, setExercise] = useState("");
  const [emotion, setEmotion] = useState<string | null>(null);

  useEffect(() => {
    if (!health) return;
    const h = Math.floor(health.sleep_hours ?? 0);
    const m = Math.round(((health.sleep_hours ?? 0) - h) * 60);
    setSleepH(h ? String(h) : "");
    setSleepM(m ? String(m) : "");
    setCondition(health.condition ?? null);
    setCoffee(health.coffee ?? 0);
    setExercise(health.exercise ?? "");
  }, [health]);

  async function handleSave() {
    const hours = (parseInt(sleepH || "0") || 0) + (parseInt(sleepM || "0") || 0) / 60;
    await upsertHealth.mutateAsync({
      date,
      updates: {
        sleep_hours: hours || undefined,
        condition: condition ?? undefined,
        coffee,
        exercise: exercise || undefined,
      },
    });
    if (emotion) {
      await upsertJournal.mutateAsync({
        date,
        updates: { emotion },
      });
    }
    toast("저장 완료");
  }

  return (
    <div className="px-7 py-4">
      <SectionLabel label="HEALTH" />
      <div className="flex gap-3 mt-2 items-center">
        <input
          type="number"
          placeholder="시"
          value={sleepH}
          onChange={(e) => setSleepH(e.target.value)}
          className="w-12 text-center bg-gray-100 border border-gray-200 rounded-md py-1"
        />
        <span>:</span>
        <input
          type="number"
          placeholder="분"
          value={sleepM}
          onChange={(e) => setSleepM(e.target.value)}
          className="w-12 text-center bg-gray-100 border border-gray-200 rounded-md py-1"
        />
        <span className="text-xs text-gray-500">수면</span>
      </div>

      <SectionLabel label="CONDITION" />
      <div className="flex gap-2 mt-2">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            onClick={() => setCondition(n)}
            className={`w-8 h-8 rounded-full text-sm ${condition === n ? "bg-black text-white" : "bg-gray-100"}`}
          >
            {n}
          </button>
        ))}
      </div>

      <SectionLabel label="EMOTION" />
      <div className="flex flex-wrap gap-2 mt-2">
        {emotionList.map((e) => (
          <button
            key={e}
            onClick={() => setEmotion(e)}
            style={{
              borderColor: emotion === e ? getEmotionColor(e) : "#e6e6e6",
              color: emotion === e ? getEmotionColor(e) : "#6B7280",
            }}
            className="px-3 py-1 rounded-full text-xs border"
          >
            {e}
          </button>
        ))}
      </div>

      <button
        onClick={handleSave}
        className="mt-4 w-full py-2.5 bg-black text-white rounded-lg text-sm font-semibold"
      >
        저장
      </button>
    </div>
  );
}

function SectionLabel({ label }: { label: string }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-[0.1em] mt-6">
      {label}
    </div>
  );
}
