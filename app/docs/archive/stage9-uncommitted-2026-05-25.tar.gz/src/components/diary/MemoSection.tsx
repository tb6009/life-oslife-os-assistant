"use client";

import { useState, useEffect } from "react";
import { useJournalEntries, useUpsertJournalEntry } from "@/lib/supabase/queries";
import { useToast } from "@/hooks/useToast";

interface Props {
  date: string;
}

export function MemoSection({ date }: Props) {
  const { data: entries } = useJournalEntries(date, date);
  const upsert = useUpsertJournalEntry();
  const { toast } = useToast();

  const [memo, setMemo] = useState("");
  const [grateful, setGrateful] = useState("");
  const [doneToday, setDoneToday] = useState("");
  const [wantTomorrow, setWantTomorrow] = useState("");
  const [noteToSelf, setNoteToSelf] = useState("");

  useEffect(() => {
    const e = entries?.[0];
    if (!e) return;
    setMemo(e.memo ?? "");
    setGrateful(e.grateful ?? "");
    setDoneToday(e.done_today ?? "");
    setWantTomorrow(e.want_tomorrow ?? "");
    setNoteToSelf(e.note_to_self ?? "");
  }, [entries]);

  async function handleSave() {
    await upsert.mutateAsync({
      date,
      updates: {
        memo,
        grateful,
        done_today: doneToday,
        want_tomorrow: wantTomorrow,
        note_to_self: noteToSelf,
      },
    });
    toast("일기 저장됨");
  }

  return (
    <div className="px-7 py-4">
      <Label>MEMO</Label>
      <textarea
        value={memo}
        onChange={(e) => setMemo(e.target.value)}
        rows={2}
        className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-1"
      />
      <Label>DAILY REVIEW</Label>
      {[
        { label: "감사한 일", v: grateful, set: setGrateful },
        { label: "오늘 한 일", v: doneToday, set: setDoneToday },
        { label: "내일 하고 싶은", v: wantTomorrow, set: setWantTomorrow },
        { label: "자신에게", v: noteToSelf, set: setNoteToSelf },
      ].map((row) => (
        <div key={row.label} className="mt-2">
          <div className="text-xs text-gray-500">{row.label}</div>
          <textarea
            value={row.v}
            onChange={(e) => row.set(e.target.value)}
            rows={2}
            className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-1 resize-none"
          />
        </div>
      ))}
      <button
        onClick={handleSave}
        className="mt-4 w-full py-2.5 bg-black text-white rounded-lg text-sm font-semibold"
      >
        저장
      </button>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-[0.1em] mt-6">
      {children}
    </div>
  );
}
