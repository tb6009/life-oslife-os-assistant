"use client";

interface Props {
  report: string;
}

export function MonthAIReport({ report }: Props) {
  if (!report) return null;
  return (
    <div className="mx-7 my-3 p-3 rounded-md border-l-4 border-blue-400" style={{ background: "linear-gradient(135deg,#fafafa,#f3f4f6)" }}>
      <div className="text-[0.58rem] text-blue-500 uppercase tracking-widest font-bold mb-1">AI Monthly Report</div>
      <div className="text-xs text-gray-700 leading-relaxed">{report}</div>
    </div>
  );
}
