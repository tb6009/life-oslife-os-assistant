"use client";

interface Props {
  sleepData: (number | null)[];
  coffeeData: (number | null)[];
  conditionData: (number | null)[];
}

export function MonthHealthCharts({ sleepData, coffeeData, conditionData }: Props) {
  const avg = (arr: (number | null)[]) => {
    const f = arr.filter((v): v is number => v !== null);
    return f.length ? f.reduce((a, b) => a + b, 0) / f.length : 0;
  };
  return (
    <div>
      <SectionLabel>Sleep / Coffee / Condition</SectionLabel>
      <div className="flex gap-0.5 px-7 items-end h-10">
        {sleepData.map((v, i) => {
          const pct = v ? Math.min((v / 10) * 100, 100) : 0;
          const isLow = v !== null && v > 0 && v < 7;
          return (
            <div key={i} className="flex-1 rounded-t" style={{
              height: `${pct}%`,
              minHeight: 2,
              background: isLow ? "linear-gradient(180deg,#fda4af,#fecdd3)" : "linear-gradient(180deg,#60A5FA,#93c5fd)"
            }} />
          );
        })}
      </div>
      <div className="px-7 text-xs text-gray-500 py-1">
        평균 수면 {avg(sleepData).toFixed(1)}h · 평균 컨디션 {avg(conditionData).toFixed(1)}/5 · 평균 커피 {avg(coffeeData).toFixed(1)}잔
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mt-5 px-7">{children}</div>
  );
}
