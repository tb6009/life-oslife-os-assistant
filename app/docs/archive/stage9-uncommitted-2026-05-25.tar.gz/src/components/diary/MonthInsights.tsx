"use client";

interface Props {
  emotionCounts: Record<string, number>;
  exerciseCount: number;
  exerciseList: string[];
  routineStats: Array<{ title: string; doneDays: number; totalDays: number }>;
}

export function MonthInsights({ emotionCounts, exerciseCount, exerciseList, routineStats }: Props) {
  const sorted = Object.entries(emotionCounts).sort((a, b) => b[1] - a[1]);
  const top = sorted[0];

  return (
    <div>
      {top && (
        <>
          <SectionLabel>Top Emotion</SectionLabel>
          <div className="px-7 text-sm">
            🟠 <strong>{top[0]}</strong> {top[1]}일
            {sorted.slice(1, 3).map(([e, n]) => <span key={e} className="text-gray-500"> · {e} {n}일</span>)}
          </div>
        </>
      )}

      <SectionLabel>Exercise + Routine</SectionLabel>
      {exerciseCount > 0 && (
        <div className="px-7 text-xs text-gray-700">
          운동 {exerciseCount}회
          {exerciseList.length > 0 && <span className="text-gray-500"> ({exerciseList.slice(0, 3).join(", ")}{exerciseList.length > 3 ? "..." : ""})</span>}
        </div>
      )}
      {routineStats.map((r) => (
        <div key={r.title} className="px-7 text-xs text-gray-700">
          {r.title} — {r.doneDays}/{r.totalDays}일
        </div>
      ))}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mt-5 px-7">{children}</div>
  );
}
