"use client";

import { useEffect, useState } from "react";
import { useMonthlyReview, useUpsertMonthlyReview } from "@/lib/supabase/queries";
import { useToast } from "@/hooks/useToast";

interface Props {
  yearMonth: string;
}

export function MonthReview({ yearMonth }: Props) {
  const { data } = useMonthlyReview(yearMonth);
  const upsert = useUpsertMonthlyReview();
  const { toast } = useToast();

  const [memorable, setMemorable] = useState("");
  const [nextGoal, setNextGoal] = useState("");
  const [noteToSelf, setNoteToSelf] = useState("");

  useEffect(() => {
    if (!data) return;
    setMemorable(data.memorable ?? "");
    setNextGoal(data.next_goal ?? "");
    setNoteToSelf(data.note_to_self ?? "");
  }, [data]);

  async function handleSave() {
    await upsert.mutateAsync({
      yearMonth,
      updates: { memorable, next_goal: nextGoal, note_to_self: noteToSelf },
    });
    toast("월간 회고 저장됨");
  }

  return (
    <div className="px-7 py-4">
      <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider">
        월간 회고
      </div>
      <textarea placeholder="이번 달 기억에 남는" value={memorable} onChange={(e) => setMemorable(e.target.value)} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-2" />
      <textarea placeholder="다음 달 목표" value={nextGoal} onChange={(e) => setNextGoal(e.target.value)} rows={3} className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-2" />
      <input type="text" placeholder="자신에게" value={noteToSelf} onChange={(e) => setNoteToSelf(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-2" />
      <button onClick={handleSave} className="mt-3 w-full py-2.5 bg-black text-white rounded-lg text-sm font-semibold">
        저장
      </button>
    </div>
  );
}
