"use client";

import { useEffect, useState } from "react";
import { useRoutines } from "@/lib/supabase/queries";
import { getRoutineLogsForDate, toggleRoutineLog, getRoutineStreak } from "@/lib/supabase/api";

interface Props {
  date: string;
}

interface RoutineItem {
  id: number;
  title: string;
  done: boolean;
  streak: number;
}

export function RoutineSection({ date }: Props) {
  const { data: routines = [] } = useRoutines();
  const [items, setItems] = useState<RoutineItem[]>([]);

  useEffect(() => {
    if (!routines.length) return;
    let cancelled = false;
    (async () => {
      const logs = (await getRoutineLogsForDate(date)) ?? [];
      const doneIds = new Set<number>(logs.filter((l: any) => l.done).map((l: any) => l.routine_id));
      const enriched: RoutineItem[] = await Promise.all(
        (routines as any[]).map(async (r) => ({
          id: r.id,
          title: r.title,
          done: doneIds.has(r.id),
          streak: await getRoutineStreak(r.id, date),
        }))
      );
      if (!cancelled) setItems(enriched);
    })();
    return () => {
      cancelled = true;
    };
  }, [routines, date]);

  async function toggle(item: RoutineItem) {
    await toggleRoutineLog(item.id, date, !item.done);
    setItems((prev) =>
      prev.map((p) => (p.id === item.id ? { ...p, done: !p.done } : p))
    );
  }

  return (
    <div className="px-7 py-4">
      <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider">
        루틴
      </div>
      {items.length === 0 ? (
        <div className="text-xs text-gray-500 mt-1">루틴 없음</div>
      ) : (
        items.map((r) => (
          <button
            key={r.id}
            onClick={() => toggle(r)}
            className="flex items-center w-full py-1.5"
          >
            <span
              className={`w-4 h-4 rounded-full border mr-2 ${
                r.done ? "bg-blue-400 border-blue-400" : "border-gray-300"
              }`}
            />
            <span
              className={`flex-1 text-left text-sm ${
                r.done ? "text-gray-500 line-through" : "text-gray-900"
              }`}
            >
              {r.title}
            </span>
            {r.streak > 0 && (
              <span className="text-xs text-blue-500">{r.streak}일</span>
            )}
          </button>
        ))
      )}
    </div>
  );
}
