"use client";

import { useEffect, useState } from "react";
import { getSchedules } from "@/lib/supabase/api";

const dayLabelsFull = ["일요일","월요일","화요일","수요일","목요일","금요일","토요일"];

interface Props {
  date: string;
}

export function ScheduleSection({ date }: Props) {
  const [schedules, setSchedules] = useState<Array<{ title: string; time: string | null }>>([]);

  useEffect(() => {
    let cancelled = false;
    getSchedules(date).then((d) => {
      if (!cancelled) setSchedules(d ?? []);
    });
    return () => {
      cancelled = true;
    };
  }, [date]);

  const d = new Date(date);
  const dayLabel = dayLabelsFull[d.getDay()];

  return (
    <div className="px-7 py-4">
      <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider">
        {d.getMonth() + 1}/{d.getDate()} ({dayLabel}) 일정
      </div>
      {schedules.length > 0 ? (
        schedules.map((s, i) => (
          <div key={i} className="text-sm text-gray-900 py-0.5">
            {s.time && (
              <span className="font-heading text-xs text-gray-500 mr-2">{s.time}</span>
            )}
            {s.title}
          </div>
        ))
      ) : (
        <div className="text-xs text-gray-500 mt-1">일정 없음</div>
      )}
    </div>
  );
}
