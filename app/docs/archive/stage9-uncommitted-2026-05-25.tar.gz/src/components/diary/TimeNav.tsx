"use client";

interface TimeNavProps {
  caption?: string;
  label: string;
  onPrev: () => void;
  onNext: () => void;
}

export function TimeNav({ caption, label, onPrev, onNext }: TimeNavProps) {
  return (
    <div className="px-7 py-2">
      {caption && (
        <div className="text-[0.65rem] uppercase tracking-wider text-gray-400 mb-0.5">
          {caption}
        </div>
      )}
      <div className="flex items-center justify-between text-[0.95rem]">
        <button
          onClick={onPrev}
          aria-label="이전"
          className="text-lg text-gray-700"
        >
          ‹
        </button>
        <span className="font-medium">{label}</span>
        <button
          onClick={onNext}
          aria-label="다음"
          className="text-lg text-gray-700"
        >
          ›
        </button>
      </div>
    </div>
  );
}
