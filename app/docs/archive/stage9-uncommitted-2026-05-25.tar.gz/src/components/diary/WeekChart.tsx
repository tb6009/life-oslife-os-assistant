"use client";

import { useHealthLogs, useJournalEntries } from "@/lib/supabase/queries";
import { getEmotionColor } from "@/lib/theme/emotions";

interface Props {
  start: string;
  end: string;
  dates: Date[];
}

export function WeekChart({ start, end, dates }: Props) {
  const { data: health = [] } = useHealthLogs(start, end);
  const { data: journals = [] } = useJournalEntries(start, end);

  const byDate = (arr: any[]) =>
    new Map(arr.map((a: any) => [a.date, a]));
  const hMap = byDate(health);
  const jMap = byDate(journals);

  return (
    <div className="px-7 py-4">
      <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mb-3">
        주간 상태
      </div>
      <div className="grid grid-cols-7 gap-1">
        {dates.map((d) => {
          const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
          const h = hMap.get(k) ?? {};
          const j = jMap.get(k) ?? {};
          const sleep = h.sleep_hours ?? 0;
          return (
            <div key={k} className="text-center">
              <div className="text-[0.6rem] text-gray-400">{["일","월","화","수","목","금","토"][d.getDay()]}</div>
              <div className="text-xs font-semibold">{d.getDate()}</div>
              <div className="mt-1 text-[0.65rem]">
                {sleep ? `${sleep.toFixed(1)}h` : "—"}
              </div>
              {j.emotion && (
                <div
                  className="w-2 h-2 rounded-full mx-auto mt-1"
                  style={{ background: getEmotionColor(j.emotion) }}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
