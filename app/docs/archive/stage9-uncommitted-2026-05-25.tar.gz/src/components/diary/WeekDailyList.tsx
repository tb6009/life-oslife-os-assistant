"use client";

interface DayDetail {
  date: string;
  dayLabel: string;
  sleep: number | null;
  condition: number | null;
  exercise: string | null;
  emotion: string | null;
}

interface Props {
  days: DayDetail[];
  exerciseList: string[];
  recommendItems: Array<{ text: string; done: boolean }>;
  todosDone: number;
  todosTotal: number;
}

export function WeekDailyList({ days, exerciseList, recommendItems, todosDone, todosTotal }: Props) {
  const todoPct = todosTotal > 0 ? Math.round((todosDone / todosTotal) * 100) : 0;
  return (
    <div>
      <SectionLabel>Daily Details</SectionLabel>
      {days.map((d) => (
        <div key={d.date} className="px-7 text-xs text-gray-700 py-0.5">
          {d.dayLabel} {d.date.slice(5)} —
          {d.sleep !== null && <> 수면 {d.sleep}h ·</>}
          {d.condition !== null && <> 컨디션 {d.condition}/5 ·</>}
          {d.emotion && <> {d.emotion}</>}
        </div>
      ))}

      {exerciseList.length > 0 && (
        <>
          <SectionLabel>Exercise Log</SectionLabel>
          {exerciseList.map((e, i) => (
            <div key={i} className="px-7 text-xs text-gray-700 py-0.5">• {e}</div>
          ))}
          <div className="px-7 text-[0.7rem] text-gray-500">총 {exerciseList.length}회</div>
        </>
      )}

      {recommendItems.length > 0 && (
        <>
          <SectionLabel>Recommendation Details</SectionLabel>
          {recommendItems.map((r, i) => (
            <div key={i} className="px-7 text-xs py-0.5" style={{ color: r.done ? "#374151" : "#9ca3af" }}>
              {r.done ? "✓" : "○"} {r.text}
            </div>
          ))}
        </>
      )}

      <SectionLabel>Todo</SectionLabel>
      <div className="px-7 text-[0.7rem] text-gray-500">완료 {todosDone} / {todosTotal} · {todoPct}%</div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mt-5 px-7">{children}</div>
  );
}
