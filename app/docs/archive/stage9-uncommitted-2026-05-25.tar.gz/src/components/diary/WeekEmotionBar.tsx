"use client";

import { getEmotionColor } from "@/lib/theme/emotions";

interface Props {
  emotions: (string | null)[]; // 7-day, may include nulls
}

export function WeekEmotionBar({ emotions }: Props) {
  const counts: Record<string, number> = {};
  emotions.forEach((e) => {
    if (!e) return;
    counts[e] = (counts[e] ?? 0) + 1;
  });
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((acc, [, n]) => acc + n, 0);

  if (total === 0) return null;

  return (
    <div>
      <SectionLabel>Emotion</SectionLabel>
      <div className="flex gap-1 px-7 h-5">
        {entries.map(([emotion, n]) => (
          <div
            key={emotion}
            style={{
              flex: n,
              background: getEmotionColor(emotion),
              borderRadius: 3,
            }}
          />
        ))}
      </div>
      <div className="flex gap-3 px-7 text-[0.65rem] text-gray-500 flex-wrap mt-1">
        {entries.map(([emotion, n]) => (
          <span key={emotion} className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full" style={{ background: getEmotionColor(emotion) }} />
            {emotion} {n}
          </span>
        ))}
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mt-5 px-7">{children}</div>
  );
}
