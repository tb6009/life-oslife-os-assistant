"use client";

interface Props {
  sleepByDay: (number | null)[];
  coffeeByDay: (number | null)[];
}

const DAYS = ["일", "월", "화", "수", "목", "금", "토"];

export function WeekHealthCharts({ sleepByDay, coffeeByDay }: Props) {
  const sleepValues = sleepByDay.map((v) => v ?? 0);
  const coffeeValues = coffeeByDay.map((v) => v ?? 0);
  const sleepAvg = avg(sleepValues);
  const coffeeAvg = avg(coffeeValues);
  const sleepGoodDays = sleepValues.filter((v) => v >= 7).length;
  const sleepBadDays = sleepValues.filter((v) => v > 0 && v < 7).length;

  return (
    <div>
      <SectionLabel>Sleep</SectionLabel>
      <ChartRow values={sleepValues} maxHint={10} lowThreshold={7} />
      <DayLabels />
      <div className="px-7 text-xs text-gray-500 py-1">
        평균 {sleepAvg.toFixed(1)}h · 7h+ {sleepGoodDays}일 / 미달 {sleepBadDays}일
      </div>

      <SectionLabel>Coffee</SectionLabel>
      <ChartRow values={coffeeValues} maxHint={5} color="#a78bfa" />
      <DayLabels />
      <div className="px-7 text-xs text-gray-500 py-1">평균 {coffeeAvg.toFixed(1)}잔</div>
    </div>
  );
}

function ChartRow({ values, maxHint, lowThreshold, color }: { values: number[]; maxHint: number; lowThreshold?: number; color?: string }) {
  const max = Math.max(maxHint, ...values);
  return (
    <div className="flex gap-1 px-7 items-end h-14">
      {values.map((v, i) => {
        const pct = max > 0 ? (v / max) * 100 : 0;
        const isLow = lowThreshold !== undefined && v > 0 && v < lowThreshold;
        const bg = color
          ? color
          : isLow
            ? "linear-gradient(180deg,#fda4af,#fecdd3)"
            : "linear-gradient(180deg,#60A5FA,#93c5fd)";
        return (
          <div
            key={i}
            className="flex-1 rounded-t"
            style={{ height: `${pct}%`, background: bg, minHeight: 2 }}
          />
        );
      })}
    </div>
  );
}

function DayLabels() {
  return (
    <div className="flex gap-1 px-7">
      {DAYS.map((d) => (
        <span key={d} className="flex-1 text-center text-[0.6rem] text-gray-400">{d}</span>
      ))}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider mt-5 px-7">{children}</div>
  );
}

function avg(arr: number[]): number {
  const filtered = arr.filter((v) => v > 0);
  if (!filtered.length) return 0;
  return filtered.reduce((a, b) => a + b, 0) / filtered.length;
}
