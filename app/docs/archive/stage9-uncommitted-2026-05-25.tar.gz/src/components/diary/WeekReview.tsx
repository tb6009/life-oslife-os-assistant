"use client";

import { useEffect, useState } from "react";
import { useWeeklyReview, useUpsertWeeklyReview } from "@/lib/supabase/queries";
import { useToast } from "@/hooks/useToast";

interface Props {
  yearWeek: string;
}

export function WeekReview({ yearWeek }: Props) {
  const { data } = useWeeklyReview(yearWeek);
  const upsert = useUpsertWeeklyReview();
  const { toast } = useToast();

  const [nextWeek, setNextWeek] = useState("");
  const [oneLine, setOneLine] = useState("");

  useEffect(() => {
    if (!data) return;
    setNextWeek(data.next_week ?? "");
    setOneLine(data.one_line ?? "");
  }, [data]);

  async function handleSave() {
    await upsert.mutateAsync({
      yearWeek,
      updates: { next_week: nextWeek, one_line: oneLine },
    });
    toast("주간 회고 저장됨");
  }

  return (
    <div className="px-7 py-4">
      <div className="font-heading text-[0.7rem] text-gray-500 uppercase tracking-wider">
        주간 회고
      </div>
      <textarea
        placeholder="한 줄"
        value={oneLine}
        onChange={(e) => setOneLine(e.target.value)}
        rows={2}
        className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-2 resize-none"
      />
      <textarea
        placeholder="다음 주에는…"
        value={nextWeek}
        onChange={(e) => setNextWeek(e.target.value)}
        rows={2}
        className="w-full bg-gray-50 border border-gray-200 rounded-md p-2 text-sm mt-2 resize-none"
      />
      <button
        onClick={handleSave}
        className="mt-3 w-full py-2.5 bg-black text-white rounded-lg text-sm font-semibold"
      >
        저장
      </button>
    </div>
  );
}
