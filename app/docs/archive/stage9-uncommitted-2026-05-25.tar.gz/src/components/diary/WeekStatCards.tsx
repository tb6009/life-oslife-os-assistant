"use client";

interface Props {
  recommendPct: number;
  todoPct: number;
}

export function WeekStatCards({ recommendPct, todoPct }: Props) {
  return (
    <div className="flex gap-2 px-7 mt-3">
      <Card num={recommendPct} label="Recommendation" />
      <Card num={todoPct} label="Todo" />
    </div>
  );
}

function Card({ num, label }: { num: number; label: string }) {
  return (
    <div className="flex-1 bg-slate-50 rounded-xl py-3 text-center">
      <div className="text-2xl font-bold text-blue-400">{num}%</div>
      <div className="text-[0.6rem] text-gray-500 mt-1 uppercase tracking-wider">{label}</div>
    </div>
  );
}
