import { render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, it, expect, vi } from "vitest";
import * as api from "@/lib/supabase/api";
import { CalendarGrid } from "../CalendarGrid";

describe("CalendarGrid", () => {
  it("renders all days of a month and fills last day green when monthly review done", async () => {
    vi.spyOn(api, "getJournalEntries").mockResolvedValue([]);
    vi.spyOn(api, "getMonthlyReview").mockResolvedValue({
      memorable: "good month",
    } as any);
    vi.spyOn(api, "getWeeklyReviewsByMonth").mockResolvedValue([]);

    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });

    render(
      <QueryClientProvider client={qc}>
        <CalendarGrid year={2026} month={5} />
      </QueryClientProvider>
    );

    // 5월은 31일
    expect(await screen.findByLabelText("2026-05-31")).toBeInTheDocument();
  });
});
