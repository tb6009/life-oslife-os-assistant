import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import { DateSelector } from "../DateSelector";

describe("DateSelector", () => {
  it("renders the centered date with day label", () => {
    const onChange = vi.fn();
    render(
      <DateSelector value={new Date(2026, 4, 11)} onChange={onChange} />
    );
    // selected day "11" visible
    expect(screen.getAllByText("11").length).toBeGreaterThan(0);
  });

  it("fires onChange when a date cell is clicked", async () => {
    const onChange = vi.fn();
    render(
      <DateSelector value={new Date(2026, 4, 11)} onChange={onChange} />
    );
    // click neighbor: "12" cell
    await userEvent.click(screen.getByLabelText(/2026-05-12/));
    expect(onChange).toHaveBeenCalled();
    const arg = onChange.mock.calls[0][0] as Date;
    expect(arg.getDate()).toBe(12);
  });

  it("renders sunday selected cell with red background", () => {
    const sunday = new Date(2026, 4, 17); // 2026-05-17 is Sun
    const { container } = render(
      <DateSelector value={sunday} onChange={vi.fn()} />
    );
    const selected = container.querySelector('[data-selected="true"]') as HTMLElement;
    expect(selected).toBeTruthy();
    expect(selected.style.backgroundColor).toMatch(/220.*38.*38|#dc2626/i);
  });
});
