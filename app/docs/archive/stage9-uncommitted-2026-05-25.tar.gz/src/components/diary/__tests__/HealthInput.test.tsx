import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ToastProvider } from "@/hooks/useToast";
import { describe, it, expect, vi } from "vitest";
import * as api from "@/lib/supabase/api";
import { HealthInput } from "../HealthInput";

function wrap() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={qc}>
      <ToastProvider>{children}</ToastProvider>
    </QueryClientProvider>
  );
}

describe("HealthInput", () => {
  it("calls upsertHealthLog when 저장 is clicked", async () => {
    const spy = vi.spyOn(api, "upsertHealthLog").mockResolvedValue(undefined as any);
    vi.spyOn(api, "getHealthLog").mockResolvedValue(null as any);

    render(<HealthInput date="2026-05-11" />, { wrapper: wrap() });

    await userEvent.click(screen.getByText("저장"));
    expect(spy).toHaveBeenCalled();
  });
});
