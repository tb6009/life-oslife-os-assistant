import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { MonthHealthCharts } from "../MonthHealthCharts";

describe("MonthHealthCharts", () => {
  it("renders averages summary", () => {
    render(
      <MonthHealthCharts
        sleepData={[7, 6, 8, null, 7]}
        coffeeData={[1, 2, 1, null, 2]}
        conditionData={[4, 3, 5, null, 4]}
      />
    );
    expect(screen.getByText(/평균 수면/)).toBeInTheDocument();
    expect(screen.getByText(/평균 컨디션/)).toBeInTheDocument();
    expect(screen.getByText(/평균 커피/)).toBeInTheDocument();
  });
});
