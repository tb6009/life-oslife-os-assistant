import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { MonthInsights } from "../MonthInsights";

describe("MonthInsights", () => {
  it("renders top emotion and routine stats", () => {
    render(
      <MonthInsights
        emotionCounts={{ 기쁨: 10, 평온: 6, 불안: 2 }}
        exerciseCount={3}
        exerciseList={["산책", "요가", "조깅"]}
        routineStats={[{ title: "아침 명상", doneDays: 22, totalDays: 31 }]}
      />
    );
    expect(screen.getByText(/기쁨/)).toBeInTheDocument();
    expect(screen.getByText(/운동 3회/)).toBeInTheDocument();
    expect(screen.getByText(/아침 명상 — 22\/31일/)).toBeInTheDocument();
  });
});
