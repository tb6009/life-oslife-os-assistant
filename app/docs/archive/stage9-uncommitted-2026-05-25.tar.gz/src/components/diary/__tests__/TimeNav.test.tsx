import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import { TimeNav } from "../TimeNav";

describe("TimeNav", () => {
  it("renders label and triggers onPrev/onNext", async () => {
    const onPrev = vi.fn();
    const onNext = vi.fn();
    render(
      <TimeNav
        label="2026-W19 · 5/10~5/16"
        onPrev={onPrev}
        onNext={onNext}
      />
    );

    expect(screen.getByText("2026-W19 · 5/10~5/16")).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: /이전/ }));
    expect(onPrev).toHaveBeenCalledTimes(1);

    await userEvent.click(screen.getByRole("button", { name: /다음/ }));
    expect(onNext).toHaveBeenCalledTimes(1);
  });

  it("renders optional caption above label", () => {
    render(
      <TimeNav
        caption="WEEK"
        label="2026-W19"
        onPrev={vi.fn()}
        onNext={vi.fn()}
      />
    );
    expect(screen.getByText("WEEK")).toBeInTheDocument();
  });
});
