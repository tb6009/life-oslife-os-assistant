import { render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, it, expect, vi } from "vitest";
import * as api from "@/lib/supabase/api";
import { WeekChart } from "../WeekChart";

describe("WeekChart", () => {
  it("renders 7 columns with sleep value", async () => {
    vi.spyOn(api, "getHealthLogs").mockResolvedValue([
      { date: "2026-05-10", sleep_hours: 7.5 } as any,
    ]);
    vi.spyOn(api, "getJournalEntries").mockResolvedValue([]);

    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    const dates = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(2026, 4, 10);
      d.setDate(d.getDate() + i);
      return d;
    });

    render(
      <QueryClientProvider client={qc}>
        <WeekChart start="2026-05-10" end="2026-05-16" dates={dates} />
      </QueryClientProvider>
    );

    expect(await screen.findByText("7.5h")).toBeInTheDocument();
  });
});
