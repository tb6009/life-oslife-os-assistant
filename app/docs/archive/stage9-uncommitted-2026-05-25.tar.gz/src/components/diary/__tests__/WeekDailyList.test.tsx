import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { WeekDailyList } from "../WeekDailyList";

describe("WeekDailyList", () => {
  it("renders daily details and todo summary", () => {
    render(
      <WeekDailyList
        days={[
          { date: "2026-05-03", dayLabel: "일", sleep: 7, condition: 4, exercise: null, emotion: "평온" },
          { date: "2026-05-04", dayLabel: "월", sleep: 6, condition: 3, exercise: null, emotion: null },
        ]}
        exerciseList={["월 — 산책"]}
        recommendItems={[{ text: "물 2L", done: true }, { text: "스트레칭", done: false }]}
        todosDone={3}
        todosTotal={5}
      />
    );
    expect(screen.getByText(/Daily Details/i)).toBeInTheDocument();
    expect(screen.getByText(/Exercise Log/i)).toBeInTheDocument();
    expect(screen.getByText(/Recommendation Details/i)).toBeInTheDocument();
    expect(screen.getByText(/완료 3 \/ 5 · 60%/)).toBeInTheDocument();
  });
});
