import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { WeekEmotionBar } from "../WeekEmotionBar";

describe("WeekEmotionBar", () => {
  it("renders nothing when no emotions", () => {
    const { container } = render(<WeekEmotionBar emotions={[null, null, null, null, null, null, null]} />);
    expect(container.firstChild).toBeNull();
  });

  it("renders top emotion legend with counts", () => {
    render(<WeekEmotionBar emotions={["기쁨", "기쁨", "평온", null, null, "기쁨", "평온"]} />);
    expect(screen.getByText(/기쁨 3/)).toBeInTheDocument();
    expect(screen.getByText(/평온 2/)).toBeInTheDocument();
  });
});
