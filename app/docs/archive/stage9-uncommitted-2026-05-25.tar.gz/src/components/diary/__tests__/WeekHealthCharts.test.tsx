import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { WeekHealthCharts } from "../WeekHealthCharts";

describe("WeekHealthCharts", () => {
  it("renders 7 sleep bars + avg label", () => {
    render(<WeekHealthCharts
      sleepByDay={[7, 6, 3.5, 7.5, 8.5, 9, 7]}
      coffeeByDay={[1, 2, 2, 3, 1, 2, 1]}
    />);
    expect(screen.getByText((_, el) => !!el && el.textContent === "평균 6.9h · 7h+ 5일 / 미달 2일")).toBeInTheDocument();
  });
});
