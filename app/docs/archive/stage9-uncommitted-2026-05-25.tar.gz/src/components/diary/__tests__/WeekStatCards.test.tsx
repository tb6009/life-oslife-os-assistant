import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { WeekStatCards } from "../WeekStatCards";

describe("WeekStatCards", () => {
  it("renders both percentages", () => {
    render(<WeekStatCards recommendPct={78} todoPct={62} />);
    expect(screen.getByText("78%")).toBeInTheDocument();
    expect(screen.getByText("62%")).toBeInTheDocument();
    expect(screen.getByText(/recommendation/i)).toBeInTheDocument();
    expect(screen.getByText(/todo/i)).toBeInTheDocument();
  });

  it("renders 0% when no data", () => {
    render(<WeekStatCards recommendPct={0} todoPct={0} />);
    expect(screen.getAllByText("0%")).toHaveLength(2);
  });
});
