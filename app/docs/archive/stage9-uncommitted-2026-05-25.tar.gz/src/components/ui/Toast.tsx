"use client";

import { useToast } from "@/hooks/useToast";

export function ToastContainer() {
  const { toasts } = useToast();
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className="px-4 py-2 rounded-full text-sm font-medium text-white bg-black/85 shadow-md"
        >
          {t.message}
        </div>
      ))}
    </div>
  );
}
