import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import { ReviewModal } from "../ReviewModal";

describe("ReviewModal", () => {
  it("renders children when open and hides when closed", () => {
    const { rerender } = render(
      <ReviewModal open={false} onClose={vi.fn()} title="T">
        <div>inside</div>
      </ReviewModal>
    );
    expect(screen.queryByText("inside")).not.toBeInTheDocument();

    rerender(
      <ReviewModal open={true} onClose={vi.fn()} title="T">
        <div>inside</div>
      </ReviewModal>
    );
    expect(screen.getByText("inside")).toBeInTheDocument();
  });

  it("closes on backdrop click and ESC", async () => {
    const onClose = vi.fn();
    render(
      <ReviewModal open={true} onClose={onClose} title="T">
        <div>inside</div>
      </ReviewModal>
    );

    // backdrop is the outermost dialog
    await userEvent.click(screen.getByRole("dialog"));
    expect(onClose).toHaveBeenCalled();

    onClose.mockClear();
    await userEvent.keyboard("{Escape}");
    expect(onClose).toHaveBeenCalled();
  });
});
