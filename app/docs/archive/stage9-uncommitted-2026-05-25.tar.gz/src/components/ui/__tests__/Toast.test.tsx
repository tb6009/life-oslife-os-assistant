import { render, screen, act } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { ToastProvider, useToast } from "@/hooks/useToast";
import { ToastContainer } from "../Toast";

function Trigger({ message }: { message: string }) {
  const { toast } = useToast();
  return <button onClick={() => toast(message)}>fire</button>;
}

describe("ToastContainer", () => {
  it("renders toast message after trigger and hides after 1500ms", () => {
    vi.useFakeTimers();
    render(
      <ToastProvider>
        <Trigger message="saved!" />
        <ToastContainer />
      </ToastProvider>
    );

    act(() => {
      screen.getByText("fire").click();
    });
    expect(screen.getByText("saved!")).toBeInTheDocument();

    act(() => vi.advanceTimersByTime(1500));
    expect(screen.queryByText("saved!")).not.toBeInTheDocument();

    vi.useRealTimers();
  });
});
