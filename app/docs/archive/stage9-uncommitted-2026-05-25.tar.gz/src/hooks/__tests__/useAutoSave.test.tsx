import { renderHook, act, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ToastProvider } from "@/hooks/useToast";
import { describe, it, expect, vi } from "vitest";
import * as api from "@/lib/supabase/api";
import { useAutoSave } from "../useAutoSave";

function wrap() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={qc}>
      <ToastProvider>{children}</ToastProvider>
    </QueryClientProvider>
  );
}

describe("useAutoSave", () => {
  it("upserts health log when text contains sleep keyword + duration", async () => {
    const spy = vi.spyOn(api, "upsertHealthLog").mockResolvedValue(undefined as any);
    const { result } = renderHook(() => useAutoSave("2026-05-11"), { wrapper: wrap() });

    await act(async () => {
      await result.current.process("어제 7시간 30분 잤어");
    });

    expect(spy).toHaveBeenCalledWith("2026-05-11", { sleep_hours: 7.5 });
  });

  it("upserts journal entry when emotion keyword present", async () => {
    const spy = vi.spyOn(api, "upsertJournalEntry").mockResolvedValue(undefined as any);
    const { result } = renderHook(() => useAutoSave("2026-05-11"), { wrapper: wrap() });

    await act(async () => {
      await result.current.process("오늘 좀 불안해");
    });

    expect(spy).toHaveBeenCalledWith("2026-05-11", { emotion: "불안" });
  });

  it("no-op when no keywords detected", async () => {
    const sleepSpy = vi.spyOn(api, "upsertHealthLog").mockResolvedValue(undefined as any);
    const journalSpy = vi.spyOn(api, "upsertJournalEntry").mockResolvedValue(undefined as any);
    const { result } = renderHook(() => useAutoSave("2026-05-11"), { wrapper: wrap() });

    await act(async () => {
      await result.current.process("그냥 인사");
    });

    expect(sleepSpy).not.toHaveBeenCalled();
    expect(journalSpy).not.toHaveBeenCalled();
  });
});
