import { renderHook, waitFor, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, it, expect, vi } from "vitest";
import * as api from "@/lib/supabase/api";
import { useChatMessages } from "../useChatMessages";

function wrap() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={qc}>{children}</QueryClientProvider>
  );
}

describe("useChatMessages", () => {
  it("loads messages for given character/date", async () => {
    vi.spyOn(api, "getChatMessages").mockResolvedValueOnce([
      { role: "user", text: "안녕" },
      { role: "assistant", text: "반가워요" },
    ] as any);

    const { result } = renderHook(
      () => useChatMessages("maeum", "2026-05-11"),
      { wrapper: wrap() }
    );

    await waitFor(() => expect(result.current.messages).toHaveLength(2));
  });

  it("sendMessage appends user + assistant + persists", async () => {
    vi.spyOn(api, "getChatMessages").mockResolvedValue([]);
    const saveSpy = vi.spyOn(api, "saveChatMessage").mockResolvedValue(undefined as any);

    const { result } = renderHook(
      () => useChatMessages("maeum", "2026-05-11"),
      { wrapper: wrap() }
    );

    await waitFor(() => expect(result.current.loaded).toBe(true));

    await act(async () => {
      await result.current.sendMessage("힘들어");
    });

    expect(saveSpy).toHaveBeenCalled();
    expect(result.current.messages.some((m) => m.text === "힘들어")).toBe(true);
  });
});
