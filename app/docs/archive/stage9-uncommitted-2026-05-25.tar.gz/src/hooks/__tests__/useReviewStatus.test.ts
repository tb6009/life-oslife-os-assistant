import { describe, it, expect } from "vitest";
import { buildDayStatus } from "../useReviewStatus";

describe("buildDayStatus", () => {
  it("marks daily done if journal has done_today text", () => {
    const status = buildDayStatus(
      new Date(2026, 4, 11),
      [{ date: "2026-05-11", done_today: "산책" }],
      new Map(),
      () => "2026-W19"
    );
    expect(status.dailyDone).toBe(true);
    expect(status.isSunday).toBe(false);
  });

  it("marks weekly done only on Sunday with weekly review one_line filled", () => {
    const sun = new Date(2026, 4, 10); // Sunday
    const status = buildDayStatus(
      sun,
      [],
      new Map([["2026-W19", { one_line: "good week" }]]),
      () => "2026-W19"
    );
    expect(status.isSunday).toBe(true);
    expect(status.weeklyDone).toBe(true);
  });
});
