import { renderHook, act } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { ToastProvider, useToast } from "../useToast";

function makeWrapper() {
  return ({ children }: { children: React.ReactNode }) => (
    <ToastProvider>{children}</ToastProvider>
  );
}

describe("useToast", () => {
  it("adds and auto-removes a toast after 1500ms", () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useToast(), { wrapper: makeWrapper() });

    act(() => result.current.toast("hello"));
    expect(result.current.toasts).toHaveLength(1);
    expect(result.current.toasts[0].message).toBe("hello");

    act(() => vi.advanceTimersByTime(1500));
    expect(result.current.toasts).toHaveLength(0);

    vi.useRealTimers();
  });

  it("supports multiple concurrent toasts", () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useToast(), { wrapper: makeWrapper() });

    act(() => {
      result.current.toast("first");
      result.current.toast("second");
    });
    expect(result.current.toasts).toHaveLength(2);

    vi.useRealTimers();
  });

  it("throws if used outside ToastProvider", () => {
    expect(() => renderHook(() => useToast())).toThrow(
      /must be used within ToastProvider/
    );
  });
});
