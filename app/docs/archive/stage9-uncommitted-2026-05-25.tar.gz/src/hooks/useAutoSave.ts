"use client";

import { useCallback } from "react";
import { useUpsertHealthLog, useUpsertJournalEntry } from "@/lib/supabase/queries";
import { useToast } from "@/hooks/useToast";
import {
  detectExercise,
  detectSleep,
  detectCoffee,
  detectCondition,
  detectEmotion,
} from "@/lib/chat/keywords";

export function useAutoSave(date: string) {
  const upsertHealth = useUpsertHealthLog();
  const upsertJournal = useUpsertJournalEntry();
  const { toast } = useToast();

  const process = useCallback(
    async (text: string) => {
      const sleep = detectSleep(text);
      if (sleep !== null) {
        await upsertHealth.mutateAsync({ date, updates: { sleep_hours: sleep } });
        toast(`수면 ${sleep}시간 저장됨`);
      }

      const coffee = detectCoffee(text);
      if (coffee !== null) {
        await upsertHealth.mutateAsync({ date, updates: { coffee } });
        toast(`커피 ${coffee}잔 저장됨`);
      }

      const condition = detectCondition(text);
      if (condition !== null) {
        await upsertHealth.mutateAsync({ date, updates: { condition } });
        toast(`컨디션 ${condition} 저장됨`);
      }

      const exercise = detectExercise(text);
      if (exercise) {
        await upsertHealth.mutateAsync({ date, updates: { exercise } });
        toast(`운동 (${exercise}) 저장됨`);
      }

      const emotion = detectEmotion(text);
      if (emotion) {
        await upsertJournal.mutateAsync({ date, updates: { emotion } });
        toast(`감정 (${emotion}) 저장됨`);
      }
    },
    [date, upsertHealth, upsertJournal, toast]
  );

  return { process };
}
