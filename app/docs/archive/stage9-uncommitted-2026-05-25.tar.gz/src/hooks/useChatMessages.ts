"use client";

import { useState, useEffect, useCallback } from "react";
import { getChatMessages, saveChatMessage } from "@/lib/supabase/api";

export interface ChatMessage {
  role: "user" | "assistant";
  character?: "momi" | "maeum";
  text: string;
}

export function useChatMessages(
  character: "momi" | "maeum",
  date: string
) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getChatMessages(character, date)
      .then((data) => {
        if (cancelled) return;
        const mapped: ChatMessage[] = (data ?? []).map((m: any) => ({
          role: m.role,
          character: m.character,
          text: m.text ?? m.message ?? "",
        }));
        setMessages(mapped);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
    return () => {
      cancelled = true;
    };
  }, [character, date]);

  const sendMessage = useCallback(
    async (text: string, assistantText?: string) => {
      const userMsg: ChatMessage = { role: "user", text };
      setMessages((prev) => [...prev, userMsg]);
      await saveChatMessage(character, "user", text, date);

      if (assistantText) {
        const botMsg: ChatMessage = {
          role: "assistant",
          character,
          text: assistantText,
        };
        setMessages((prev) => [...prev, botMsg]);
        await saveChatMessage(character, "assistant", assistantText, date);
      }
    },
    [character, date]
  );

  return { messages, loaded, sendMessage };
}
