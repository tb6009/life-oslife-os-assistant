"use client";

export interface DayStatus {
  date: string;        // YYYY-MM-DD
  dailyDone: boolean;
  weeklyDone: boolean; // only meaningful for Sunday
  isSunday: boolean;
}

export function buildDayStatus(
  date: Date,
  journals: Array<{ date: string; done_today?: string | null }>,
  weeklyReviewByWeek: Map<string, { one_line?: string | null } | undefined>,
  yearWeekFor: (d: Date) => string
): DayStatus {
  const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const j = journals.find((x) => x.date === dateStr);
  const dailyDone = !!(j?.done_today && j.done_today.trim().length > 0);
  const isSunday = date.getDay() === 0;
  let weeklyDone = false;
  if (isSunday) {
    const wr = weeklyReviewByWeek.get(yearWeekFor(date));
    weeklyDone = !!(wr?.one_line && wr.one_line.trim().length > 0);
  }
  return { date: dateStr, dailyDone, weeklyDone, isSunday };
}
