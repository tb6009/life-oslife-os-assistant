import { describe, it, expect } from "vitest";
import { renderMarkdown } from "../markdown";

describe("renderMarkdown", () => {
  it("converts **bold** to <strong>", () => {
    expect(renderMarkdown("**hi**")).toContain("<strong>hi</strong>");
  });
  it("converts *italic* to <em>", () => {
    expect(renderMarkdown("*hi*")).toContain("<em>hi</em>");
  });
  it("converts `code` to <code>", () => {
    expect(renderMarkdown("`x`")).toContain("<code");
  });
  it("converts newlines to <br>", () => {
    expect(renderMarkdown("a\nb")).toContain("<br>");
  });
});
