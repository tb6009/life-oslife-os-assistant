import { describe, it, expect } from "vitest";

describe("sanity", () => {
  it("addition works", () => {
    expect(1 + 1).toBe(2);
  });
});
