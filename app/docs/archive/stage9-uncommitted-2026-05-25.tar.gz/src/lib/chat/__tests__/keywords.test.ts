import { describe, it, expect } from "vitest";
import {
  detectExercise,
  detectSleep,
  detectCoffee,
  detectCondition,
  detectEmotion,
} from "../keywords";

describe("detectExercise", () => {
  it("returns exercise name with optional duration", () => {
    expect(detectExercise("오늘 30분 조깅했어")).toBe("조깅 30분");
    expect(detectExercise("산책 좀 했어")).toBe("산책");
    expect(detectExercise("그냥 누워있었어")).toBeNull();
  });
});

describe("detectSleep", () => {
  it("returns hours when sleep keyword + duration present", () => {
    expect(detectSleep("7시간 30분 잤어")).toBe(7.5);
    expect(detectSleep("8시간 수면")).toBe(8);
    expect(detectSleep("그냥 잤음")).toBeNull(); // no duration → null
  });
});

describe("detectCoffee", () => {
  it("returns coffee count", () => {
    expect(detectCoffee("커피 3잔 마셨어")).toBe(3);
    expect(detectCoffee("물 마심")).toBeNull();
  });
});

describe("detectCondition", () => {
  it("returns 1-5 condition", () => {
    expect(detectCondition("컨디션 4")).toBe(4);
    expect(detectCondition("컨디션 6")).toBeNull(); // out of range
  });
});

describe("detectEmotion", () => {
  it("returns emotion keyword", () => {
    expect(detectEmotion("오늘 기쁘다")).toBe("기쁨");
    expect(detectEmotion("좀 불안해")).toBe("불안");
    expect(detectEmotion("배고프다")).toBeNull();
  });
});
