const EXERCISE_KEYWORDS = [
  "조깅", "달리기", "걷기", "산책", "수영", "헬스", "웨이트",
  "요가", "필라테스", "스트레칭", "자전거", "등산", "인라인",
  "축구", "농구", "테니스", "배드민턴", "골프",
];

export function detectExercise(text: string): string | null {
  const found = EXERCISE_KEYWORDS.find((k) => text.includes(k));
  if (!found) return null;
  const m = text.match(/(\d+)\s*분/);
  return m ? `${found} ${m[1]}분` : found;
}

export function detectSleep(text: string): number | null {
  const hint = ["잤", "수면", "잠"].some((k) => text.includes(k));
  const m = text.match(/(\d+)\s*시간\s*(?:(\d+)\s*분)?/);
  if (!hint || !m) return null;
  const h = parseInt(m[1], 10);
  const min = parseInt(m[2] ?? "0", 10);
  return Math.round((h + min / 60) * 10) / 10;
}

export function detectCoffee(text: string): number | null {
  const m = text.match(/커피\s*(\d+)\s*잔/);
  return m ? parseInt(m[1], 10) : null;
}

export function detectCondition(text: string): number | null {
  const m = text.match(/컨디션\s*(\d)/);
  if (!m) return null;
  const v = parseInt(m[1], 10);
  return v >= 1 && v <= 5 ? v : null;
}

const EMOTION_MAP: Record<string, string> = {
  "기쁘": "기쁨", "좋아": "기쁨", "좋은": "기쁨",
  "감사": "감사", "평온": "평온", "설레": "설렘",
  "무기력": "무기력", "불안": "불안", "짜증": "짜증",
  "슬프": "슬픔", "피곤": "피곤", "외롭": "외로움",
  "막막": "막막", "우울": "우울",
};

export function detectEmotion(text: string): string | null {
  for (const [keyword, emotion] of Object.entries(EMOTION_MAP)) {
    if (text.includes(keyword)) return emotion;
  }
  return null;
}
