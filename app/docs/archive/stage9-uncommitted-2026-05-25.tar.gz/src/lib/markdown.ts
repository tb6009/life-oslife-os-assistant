export function renderMarkdown(text: string): string {
  return text
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(
      /`([^`]+)`/g,
      '<code style="background:#f2f2f2;padding:1px 4px;border-radius:3px;font-size:0.78rem;">$1</code>'
    )
    .replace(/\n/g, "<br>");
}
