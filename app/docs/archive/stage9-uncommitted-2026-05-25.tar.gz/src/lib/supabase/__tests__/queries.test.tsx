import { renderHook, waitFor, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { describe, it, expect, vi } from "vitest";
import {
  useHealthLog,
  useHealthLogs,
  useJournalEntries,
  useRoutines,
  useRoutineLogsByRange,
  useWeeklyReview,
  useMonthlyReview,
  useUpsertHealthLog,
  useUpsertJournalEntry,
  useUpsertWeeklyReview,
  useUpsertMonthlyReview,
} from "../queries";
import * as api from "../api";

function makeWrapper() {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
}

describe("useHealthLog", () => {
  it("returns data from getHealthLog", async () => {
    vi.spyOn(api, "getHealthLog").mockResolvedValueOnce({
      sleep_hours: 7,
      condition: 4,
      exercise: null,
      coffee: 0,
    });

    const { result } = renderHook(() => useHealthLog("2026-05-11"), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data?.sleep_hours).toBe(7);
  });

  it("does not refetch on remount within staleTime", async () => {
    const spy = vi.spyOn(api, "getHealthLog").mockResolvedValue({
      sleep_hours: 7,
    });
    const Wrapper = makeWrapper();

    const { rerender } = renderHook(() => useHealthLog("2026-05-12"), {
      wrapper: Wrapper,
    });
    await waitFor(() => expect(spy).toHaveBeenCalledTimes(1));

    rerender();
    expect(spy).toHaveBeenCalledTimes(1);
  });
});

describe("useHealthLogs (range)", () => {
  it("returns array of health logs and caches by [start,end]", async () => {
    vi.spyOn(api, "getHealthLogs").mockResolvedValueOnce([
      { date: "2026-05-10", sleep_hours: 7 },
      { date: "2026-05-11", sleep_hours: 8 },
    ] as any);

    const { result } = renderHook(
      () => useHealthLogs("2026-05-10", "2026-05-16"),
      { wrapper: makeWrapper() }
    );

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toHaveLength(2);
  });
});

describe("useJournalEntries (range)", () => {
  it("returns journal entries in range", async () => {
    vi.spyOn(api, "getJournalEntries").mockResolvedValueOnce([
      { date: "2026-05-10", memo: "x" },
    ] as any);

    const { result } = renderHook(
      () => useJournalEntries("2026-05-10", "2026-05-16"),
      { wrapper: makeWrapper() }
    );

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toHaveLength(1);
  });
});

describe("useRoutines", () => {
  it("returns routines list", async () => {
    vi.spyOn(api, "getRoutines").mockResolvedValueOnce([
      { id: 1, title: "산책", active: true },
    ] as any);

    const { result } = renderHook(() => useRoutines(), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toHaveLength(1);
  });
});

describe("useRoutineLogsByRange", () => {
  it("returns routine logs in range", async () => {
    vi.spyOn(api, "getRoutineLogsByRange").mockResolvedValueOnce([
      { routine_id: 1, date: "2026-05-10", done: true },
    ] as any);

    const { result } = renderHook(
      () => useRoutineLogsByRange("2026-05-10", "2026-05-16"),
      { wrapper: makeWrapper() }
    );

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toHaveLength(1);
  });
});

describe("useWeeklyReview", () => {
  it("returns weekly review by yearWeek", async () => {
    vi.spyOn(api, "getWeeklyReview").mockResolvedValueOnce({
      year_week: "2026-W19",
      one_line: "good",
    } as any);

    const { result } = renderHook(() => useWeeklyReview("2026-W19"), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data?.one_line).toBe("good");
  });
});

describe("useMonthlyReview", () => {
  it("returns monthly review by yearMonth", async () => {
    vi.spyOn(api, "getMonthlyReview").mockResolvedValueOnce({
      year_month: "2026-05",
      memorable: "good",
    } as any);

    const { result } = renderHook(() => useMonthlyReview("2026-05"), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data?.memorable).toBe("good");
  });
});

describe("useUpsertHealthLog (mutation + invalidation)", () => {
  it("calls upsertHealthLog and invalidates health-log query", async () => {
    const upsertSpy = vi
      .spyOn(api, "upsertHealthLog")
      .mockResolvedValueOnce(undefined as any);

    const client = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });
    const wrapper = ({ children }: { children: React.ReactNode }) => (
      <QueryClientProvider client={client}>{children}</QueryClientProvider>
    );

    const { result } = renderHook(() => useUpsertHealthLog(), { wrapper });

    await act(async () => {
      await result.current.mutateAsync({
        date: "2026-05-11",
        updates: { sleep_hours: 7 },
      });
    });

    expect(upsertSpy).toHaveBeenCalledWith("2026-05-11", { sleep_hours: 7 });
  });
});

describe("useUpsertJournalEntry", () => {
  it("calls upsertJournalEntry with date+updates", async () => {
    const spy = vi
      .spyOn(api, "upsertJournalEntry")
      .mockResolvedValueOnce(undefined as any);

    const { result } = renderHook(() => useUpsertJournalEntry(), {
      wrapper: makeWrapper(),
    });

    await act(async () => {
      await result.current.mutateAsync({
        date: "2026-05-11",
        updates: { memo: "hello" },
      });
    });

    expect(spy).toHaveBeenCalledWith("2026-05-11", { memo: "hello" });
  });
});

describe("useUpsertWeeklyReview", () => {
  it("calls upsertWeeklyReview with yearWeek+updates", async () => {
    const spy = vi
      .spyOn(api, "upsertWeeklyReview")
      .mockResolvedValueOnce(undefined as any);

    const { result } = renderHook(() => useUpsertWeeklyReview(), {
      wrapper: makeWrapper(),
    });

    await act(async () => {
      await result.current.mutateAsync({
        yearWeek: "2026-W19",
        updates: { one_line: "ok" },
      });
    });

    expect(spy).toHaveBeenCalledWith("2026-W19", { one_line: "ok" });
  });
});

describe("useUpsertMonthlyReview", () => {
  it("calls upsertMonthlyReview with yearMonth+updates", async () => {
    const spy = vi
      .spyOn(api, "upsertMonthlyReview")
      .mockResolvedValueOnce(undefined as any);

    const { result } = renderHook(() => useUpsertMonthlyReview(), {
      wrapper: makeWrapper(),
    });

    await act(async () => {
      await result.current.mutateAsync({
        yearMonth: "2026-05",
        updates: { memorable: "ok" },
      });
    });

    expect(spy).toHaveBeenCalledWith("2026-05", { memorable: "ok" });
  });
});
