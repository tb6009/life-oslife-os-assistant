"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import * as api from "./api";

export function useHealthLog(date: string) {
  return useQuery({
    queryKey: ["health-log", date],
    queryFn: () => api.getHealthLog(date),
  });
}

// --- Queries (range / by-key) ---

export function useHealthLogs(start: string, end: string) {
  return useQuery({
    queryKey: ["health-logs", start, end],
    queryFn: () => api.getHealthLogs(start, end),
  });
}

export function useJournalEntries(start: string, end: string) {
  return useQuery({
    queryKey: ["journal-entries", start, end],
    queryFn: () => api.getJournalEntries(start, end),
  });
}

export function useRoutines() {
  return useQuery({
    queryKey: ["routines"],
    queryFn: () => api.getRoutines(),
  });
}

export function useRoutineLogsByRange(start: string, end: string) {
  return useQuery({
    queryKey: ["routine-logs", start, end],
    queryFn: () => api.getRoutineLogsByRange(start, end),
  });
}

export function useRecommendationLogs(start: string, end: string) {
  return useQuery({
    queryKey: ["recommendation-logs", start, end],
    queryFn: () => api.getRecommendationLogs(start, end),
  });
}

export function useTodos() {
  return useQuery({
    queryKey: ["todos"],
    queryFn: () => api.getTodos(),
  });
}

export function useWeeklyReview(yearWeek: string) {
  return useQuery({
    queryKey: ["weekly-review", yearWeek],
    queryFn: () => api.getWeeklyReview(yearWeek),
  });
}

export function useMonthlyReview(yearMonth: string) {
  return useQuery({
    queryKey: ["monthly-review", yearMonth],
    queryFn: () => api.getMonthlyReview(yearMonth),
  });
}

export function useWeeklyReviewsByMonth(yearMonth: string) {
  return useQuery({
    queryKey: ["weekly-reviews-by-month", yearMonth],
    queryFn: () => api.getWeeklyReviewsByMonth(yearMonth),
  });
}

// --- Mutations (with cache invalidation) ---

export function useUpsertHealthLog() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (vars: { date: string; updates: Parameters<typeof api.upsertHealthLog>[1] }) =>
      api.upsertHealthLog(vars.date, vars.updates),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["health-log", vars.date] });
      qc.invalidateQueries({ queryKey: ["health-logs"] });
    },
  });
}

export function useUpsertJournalEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (vars: { date: string; updates: Parameters<typeof api.upsertJournalEntry>[1] }) =>
      api.upsertJournalEntry(vars.date, vars.updates),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["journal-entry", vars.date] });
      qc.invalidateQueries({ queryKey: ["journal-entries"] });
    },
  });
}

export function useUpsertWeeklyReview() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (vars: { yearWeek: string; updates: Parameters<typeof api.upsertWeeklyReview>[1] }) =>
      api.upsertWeeklyReview(vars.yearWeek, vars.updates),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["weekly-review", vars.yearWeek] });
    },
  });
}

export function useUpsertMonthlyReview() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (vars: { yearMonth: string; updates: Parameters<typeof api.upsertMonthlyReview>[1] }) =>
      api.upsertMonthlyReview(vars.yearMonth, vars.updates),
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["monthly-review", vars.yearMonth] });
    },
  });
}
