import { describe, it, expect } from "vitest";
import { getWeekRange, getMonthRange, toDateStr, getYearWeek } from "../range";

describe("toDateStr", () => {
  it("formats YYYY-MM-DD with zero padding", () => {
    expect(toDateStr(new Date(2026, 4, 3))).toBe("2026-05-03");
  });
});

describe("getWeekRange(date)", () => {
  it("returns Sun-Sat range for given date", () => {
    // 2026-05-11 is Monday
    const r = getWeekRange(new Date(2026, 4, 11));
    expect(r.start).toBe("2026-05-10");
    expect(r.end).toBe("2026-05-16");
    expect(r.dates).toHaveLength(7);
  });

  it("supports navigating to previous week", () => {
    const base = new Date(2026, 4, 11);
    const prev = new Date(base);
    prev.setDate(prev.getDate() - 7);
    const r = getWeekRange(prev);
    expect(r.start).toBe("2026-05-03");
    expect(r.end).toBe("2026-05-09");
  });
});

describe("getYearWeek", () => {
  it("returns 2026-W19 for 2026-05-11", () => {
    expect(getYearWeek(new Date(2026, 4, 11))).toBe("2026-W19");
  });
});

describe("getMonthRange(year, month)", () => {
  it("returns first and last day of given month", () => {
    const r = getMonthRange(2026, 5);
    expect(r.start).toBe("2026-05-01");
    expect(r.end).toBe("2026-05-31");
    expect(r.days).toBe(31);
    expect(r.firstDayOfWeek).toBe(5); // 2026-05-01 is Friday
  });
});
