export function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export interface WeekRange {
  start: string;
  end: string;
  dates: Date[];
}

export function getWeekRange(date: Date): WeekRange {
  const day = date.getDay();
  const sun = new Date(date);
  sun.setDate(date.getDate() - day);
  const dates: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(sun);
    d.setDate(sun.getDate() + i);
    dates.push(d);
  }
  return { start: toDateStr(dates[0]), end: toDateStr(dates[6]), dates };
}

export function getYearWeek(date: Date): string {
  const y = date.getFullYear();
  // Sunday that starts the week containing `date`
  const sun = new Date(date);
  sun.setDate(date.getDate() - date.getDay());
  // First Sunday of the year (W1 begins here, Sunday-start convention)
  const yStart = new Date(y, 0, 1);
  const firstSun = new Date(yStart);
  firstSun.setDate(1 + ((7 - yStart.getDay()) % 7));
  const weeks = Math.round(
    (sun.getTime() - firstSun.getTime()) / (7 * 86400000)
  );
  const weekNum = weeks + 1;
  return `${y}-W${String(weekNum).padStart(2, "0")}`;
}

export interface MonthRange {
  start: string;
  end: string;
  days: number;
  firstDayOfWeek: number; // 0=Sun
}

export function getMonthRange(year: number, month: number): MonthRange {
  const days = new Date(year, month, 0).getDate();
  const firstDayOfWeek = new Date(year, month - 1, 1).getDay();
  return {
    start: `${year}-${String(month).padStart(2, "0")}-01`,
    end: `${year}-${String(month).padStart(2, "0")}-${String(days).padStart(2, "0")}`,
    days,
    firstDayOfWeek,
  };
}
