import "@testing-library/jest-dom/vitest";

// Stub Supabase env vars so client module can initialize during tests.
// Real DB calls are mocked at the api.* function level.
process.env.NEXT_PUBLIC_SUPABASE_URL ??= "http://localhost:54321";
process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ??= "test-anon-key";
